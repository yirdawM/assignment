// check if screen is mobile
const isMobile = () => window.innerWidth <= 768;

// selectors
const footer = $(".footer-links-wrapper");
const headings = footer.find("h3");
const lists = footer.find("ul");

// initial state
if (isMobile()) {
  lists.hide();
}

// click event for headings
headings.on("click", function () {
  if (!isMobile()) return;

  const heading = $(this);
  const list = heading.next("ul");

  list.slideToggle(500);
  heading.toggleClass("expanded");
});

// handle window resize
$(window).on("resize", function () {
  if (isMobile()) {
    lists.hide();
  } else {
    lists.show();
  }

  headings.removeClass("expanded");
});